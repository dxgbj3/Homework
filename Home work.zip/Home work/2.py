a = int(input(': '))
b = int(input(': '))
month = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

for i in range(a, b+1):
    print(month[i-1])