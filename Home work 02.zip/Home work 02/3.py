a = input('Number: ')
b = input('Number: ')
c = input('Number: ')

print(a + b + c)