a = int(input("Triangle base: "))
h = int(input("Height: "))
print('S =', a*h/2)